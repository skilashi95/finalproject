import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        new ToDoApp();
    }
}

class ToDoApp {
    private Scanner input = new Scanner(System.in).useDelimiter("\n");
    private List<Task> taskList = new ArrayList();

    public ToDoApp() {
        displayMainMenu();
    }

    private void displayMainMenu() {
        String menu = "Select task action number\n" +
                "1. Add a task\n" +
                "2. Mark task as done\n" +
                "3. Remove task\n" +
                "4. Edit task\n" +
                "5. Display all tasks\n" +
                "6. Exit\n";

        int selectedTaskActionId = 0;
        do {
            System.out.println(menu);
            selectedTaskActionId = input.nextInt();
            switch (selectedTaskActionId) {
                case 1:
                    addTask();
                    break;
                case 2:
                    displayMarkTaskAsDone();
                    break;
                case 3:
                    removeTask();
                    break;
                case 4:
                    editTask();
                    break;
                case 5:
                    displayAllTasks();
                    break;
                case 6:
                    exitProgram();
                    break;
            }
        } while (selectedTaskActionId == 0);
    }

    private void addTask() {
        System.out.println("Enter title :");
        String title = input.next();

        String dueDateString;
        Date dueDate = null;
        System.out.println("Enter due date (dd/MM/yyyy):");
        do {
            dueDateString = input.next();
            try {
                if (!dueDateString.isEmpty())
                    dueDate = new SimpleDateFormat("dd/MM/yyyy").parse(dueDateString);
            } catch (ParseException exception) {

            }
        } while (dueDate == null);

        System.out.println("Enter description:");
        String description = input.next();

        int id = taskList.size() + 1;
        Task task = new Task(id, title, dueDate, description);
        taskList.add(task);
        displayAllTasks();
        displayMainMenu();
    }

    private void displayMarkTaskAsDone() {
        System.out.println();
        int id = 0;
        do {
            System.out.println("-------- Enter task # to mark as done: ----------");
            while (!input.hasNextInt()) {
                System.out.println("That's not a number!\nPlease select the task number");
                input.next();
            }
            id = input.nextInt();
            if (id <= taskList.size()) {
                int taskIndex = id - 1;
                taskList.get(taskIndex).setStatus(Task.Status.DONE);
                System.out.println("-------- Marked as done --------");
                displayMainMenu();
            } else {
                System.out.println("-------- Task doesn't exist ----------");
            }
        } while (id == 0 || id < taskList.size());
    }

    private void editTask() {
        int id = 0;

        System.out.println("Enter task # to edit:");
        id = input.nextInt();
        if (id <= taskList.size()) {
            System.out.println("Enter title :");
            String title = input.next();

            String dueDateString;
            Date dueDate = null;
            System.out.println("Enter due date (dd/MM/yyyy):");
            do {
                dueDateString = input.next();
                try {
                    if (!dueDateString.isEmpty())
                        dueDate = new SimpleDateFormat("dd/MM/yyyy").parse(dueDateString);
                } catch (ParseException exception) {

                }
            } while (dueDate == null);

            System.out.println("Enter description:");
            String description = input.next();

            int taskIndex = taskList.size() - 1;
            taskList.get(taskIndex).setTitle(title);
            taskList.get(taskIndex).setDescription(description);
            taskList.get(taskIndex).setDueDate(dueDate);
            System.out.println("Task edited");
            displayMainMenu();
        } else {
            System.out.println("No task.\nCreate a task");
            displayMainMenu();
        }
    }

    private void removeTask() {
        int id = 0;

        do {
            System.out.println("Enter task # to remove:");
            id = input.nextInt();
            if (id <= taskList.size()) {
                taskList.remove(id - 1);
                System.out.println("Task deleted");
                displayMainMenu();
            }
        } while (id != 0 || id < taskList.size());
    }

    private void displayAllTasks() {
        if (taskList.size() == 0) {
            System.out.println("==================================");
            System.out.println("======== No task to display ======");
            System.out.println("==================================");
            System.out.println();
            displayMainMenu();
            return;
        }
        System.out.println("============================");
        System.out.println("======== To-do list ========");
        System.out.println("============================");
        System.out.println(taskList.toString());
    }

    private void exitProgram() {
        System.exit(0);
    }
}

class Task {

    enum Status {
        PENDING,
        DONE
    }
    private int id;
    private String title;
    private Date dueDate;
    private Status status;
    private String description;

    @Override
    public String toString() {
        return "Task" +
                " #" + id +
                ", title='" + title + '\'' +
                ", dueDate='" + dueDate + '\'' +
                ", status='" + status + '\'' +
                ", description='" + description + '\'';
    }

    public Task(int id, String title, Date dueDate, String description) {
        this.id = id;
        this.title = title;
        this.dueDate = dueDate;
        this.status = Status.PENDING;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}